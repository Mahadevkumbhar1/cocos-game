
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Star.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd2900rDz49MVrDvLJapvFEX', 'Star');
// scripts/Star.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    pickRadius: 0
  },
  getPlayerDistance: function getPlayerDistance() {
    if (!this.game || !this.game.player) {
      // Handle the case where this.game or this.game.player is not defined
      return Number.MAX_VALUE; // or any other appropriate value
    }

    var playerPos = this.game.player.getPosition();
    var dist = this.node.position.sub(playerPos).mag();
    return dist;
  },
  onPicked: function onPicked() {
    if (this.game) {
      this.game.spawnNewStar();
    }

    if (this.game && this.game.gainScore) {
      this.game.gainScore();
    }

    this.node.destroy();
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    if (this.getPlayerDistance() < this.pickRadius) {
      this.onPicked();
      return;
    }

    var opacityRadio = 1 - this.game.timer / this.game.starDuration;
    var minOpacity = 50;
    this.node.opacity = minOpacity + Math.floor(opacityRadio * (255 - minOpacity));
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcU3Rhci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInBpY2tSYWRpdXMiLCJnZXRQbGF5ZXJEaXN0YW5jZSIsImdhbWUiLCJwbGF5ZXIiLCJOdW1iZXIiLCJNQVhfVkFMVUUiLCJwbGF5ZXJQb3MiLCJnZXRQb3NpdGlvbiIsImRpc3QiLCJub2RlIiwicG9zaXRpb24iLCJzdWIiLCJtYWciLCJvblBpY2tlZCIsInNwYXduTmV3U3RhciIsImdhaW5TY29yZSIsImRlc3Ryb3kiLCJzdGFydCIsInVwZGF0ZSIsImR0Iiwib3BhY2l0eVJhZGlvIiwidGltZXIiLCJzdGFyRHVyYXRpb24iLCJtaW5PcGFjaXR5Iiwib3BhY2l0eSIsIk1hdGgiLCJmbG9vciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBRTtBQURKLEdBSFA7QUFPTEMsRUFBQUEsaUJBQWlCLEVBQUUsNkJBQVc7QUFDMUIsUUFBSSxDQUFDLEtBQUtDLElBQU4sSUFBYyxDQUFDLEtBQUtBLElBQUwsQ0FBVUMsTUFBN0IsRUFBcUM7QUFDakM7QUFDQSxhQUFPQyxNQUFNLENBQUNDLFNBQWQsQ0FGaUMsQ0FFUjtBQUM1Qjs7QUFFRCxRQUFJQyxTQUFTLEdBQUcsS0FBS0osSUFBTCxDQUFVQyxNQUFWLENBQWlCSSxXQUFqQixFQUFoQjtBQUNBLFFBQUlDLElBQUksR0FBRyxLQUFLQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJDLEdBQW5CLENBQXVCTCxTQUF2QixFQUFrQ00sR0FBbEMsRUFBWDtBQUNBLFdBQU9KLElBQVA7QUFDSCxHQWhCSTtBQWtCTEssRUFBQUEsUUFBUSxFQUFFLG9CQUFXO0FBQ2pCLFFBQUksS0FBS1gsSUFBVCxFQUFlO0FBQ1gsV0FBS0EsSUFBTCxDQUFVWSxZQUFWO0FBQ0g7O0FBRUQsUUFBSSxLQUFLWixJQUFMLElBQWEsS0FBS0EsSUFBTCxDQUFVYSxTQUEzQixFQUFzQztBQUNsQyxXQUFLYixJQUFMLENBQVVhLFNBQVY7QUFDSDs7QUFFRCxTQUFLTixJQUFMLENBQVVPLE9BQVY7QUFDSCxHQTVCSTtBQThCTDtBQUVBO0FBRUFDLEVBQUFBLEtBbENLLG1CQWtDSSxDQUVSLENBcENJO0FBc0NMQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNqQixRQUFJLEtBQUtsQixpQkFBTCxLQUEyQixLQUFLRCxVQUFwQyxFQUErQztBQUMzQyxXQUFLYSxRQUFMO0FBQ0E7QUFDSDs7QUFFRCxRQUFJTyxZQUFZLEdBQUcsSUFBSSxLQUFLbEIsSUFBTCxDQUFVbUIsS0FBVixHQUFnQixLQUFLbkIsSUFBTCxDQUFVb0IsWUFBakQ7QUFDQSxRQUFJQyxVQUFVLEdBQUcsRUFBakI7QUFDQSxTQUFLZCxJQUFMLENBQVVlLE9BQVYsR0FBb0JELFVBQVUsR0FBR0UsSUFBSSxDQUFDQyxLQUFMLENBQVdOLFlBQVksSUFBSSxNQUFNRyxVQUFWLENBQXZCLENBQWpDO0FBQ0g7QUEvQ0ksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBwaWNrUmFkaXVzOiAwLFxyXG4gICAgfSxcclxuXHJcbiAgICBnZXRQbGF5ZXJEaXN0YW5jZTogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmdhbWUgfHwgIXRoaXMuZ2FtZS5wbGF5ZXIpIHtcclxuICAgICAgICAgICAgLy8gSGFuZGxlIHRoZSBjYXNlIHdoZXJlIHRoaXMuZ2FtZSBvciB0aGlzLmdhbWUucGxheWVyIGlzIG5vdCBkZWZpbmVkXHJcbiAgICAgICAgICAgIHJldHVybiBOdW1iZXIuTUFYX1ZBTFVFOyAvLyBvciBhbnkgb3RoZXIgYXBwcm9wcmlhdGUgdmFsdWVcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZhciBwbGF5ZXJQb3MgPSB0aGlzLmdhbWUucGxheWVyLmdldFBvc2l0aW9uKCk7XHJcbiAgICAgICAgdmFyIGRpc3QgPSB0aGlzLm5vZGUucG9zaXRpb24uc3ViKHBsYXllclBvcykubWFnKCk7XHJcbiAgICAgICAgcmV0dXJuIGRpc3Q7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uUGlja2VkOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBpZiAodGhpcy5nYW1lKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZS5zcGF3bk5ld1N0YXIoKTtcclxuICAgICAgICB9XHJcbiAgICBcclxuICAgICAgICBpZiAodGhpcy5nYW1lICYmIHRoaXMuZ2FtZS5nYWluU2NvcmUpIHtcclxuICAgICAgICAgICAgdGhpcy5nYW1lLmdhaW5TY29yZSgpO1xyXG4gICAgICAgIH1cclxuICAgIFxyXG4gICAgICAgIHRoaXMubm9kZS5kZXN0cm95KCk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG4gICAgICAgIGlmICh0aGlzLmdldFBsYXllckRpc3RhbmNlKCkgPCB0aGlzLnBpY2tSYWRpdXMpe1xyXG4gICAgICAgICAgICB0aGlzLm9uUGlja2VkKCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZhciBvcGFjaXR5UmFkaW8gPSAxIC0gdGhpcy5nYW1lLnRpbWVyL3RoaXMuZ2FtZS5zdGFyRHVyYXRpb247XHJcbiAgICAgICAgdmFyIG1pbk9wYWNpdHkgPSA1MDtcclxuICAgICAgICB0aGlzLm5vZGUub3BhY2l0eSA9IG1pbk9wYWNpdHkgKyBNYXRoLmZsb29yKG9wYWNpdHlSYWRpbyAqICgyNTUgLSBtaW5PcGFjaXR5KSk7XHJcbiAgICB9LFxyXG59KTtcclxuIl19