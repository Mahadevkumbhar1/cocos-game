"use strict";
cc._RF.push(module, 'd2900rDz49MVrDvLJapvFEX', 'Star');
// scripts/Star.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    pickRadius: 0
  },
  getPlayerDistance: function getPlayerDistance() {
    if (!this.game || !this.game.player) {
      // Handle the case where this.game or this.game.player is not defined
      return Number.MAX_VALUE; // or any other appropriate value
    }

    var playerPos = this.game.player.getPosition();
    var dist = this.node.position.sub(playerPos).mag();
    return dist;
  },
  onPicked: function onPicked() {
    if (this.game) {
      this.game.spawnNewStar();
    }

    if (this.game && this.game.gainScore) {
      this.game.gainScore();
    }

    this.node.destroy();
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    if (this.getPlayerDistance() < this.pickRadius) {
      this.onPicked();
      return;
    }

    var opacityRadio = 1 - this.game.timer / this.game.starDuration;
    var minOpacity = 50;
    this.node.opacity = minOpacity + Math.floor(opacityRadio * (255 - minOpacity));
  }
});

cc._RF.pop();