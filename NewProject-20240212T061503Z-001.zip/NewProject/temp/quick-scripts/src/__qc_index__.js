
require('./assets/scripts/Game - 001');
require('./assets/scripts/Game');
require('./assets/scripts/Player - 001');
require('./assets/scripts/Player');
require('./assets/scripts/Star - 001');
require('./assets/scripts/Star');
