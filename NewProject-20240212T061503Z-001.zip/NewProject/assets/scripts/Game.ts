// const { ccclass, property } = cc._decorator;

@ccclass
export default class YourComponentName extends cc.Component {

    @property(cc.Prefab)
    starPrefab: cc.Prefab = null;

    @property
    maxStarDuration: number = 0;

    @property
    minStarDuration: number = 0;

    @property(cc.Node)
    ground: cc.Node = null;

    @property(cc.Node)
    player: cc.Node = null;

    @property(cc.Label)
    scoreDisplay: cc.Label = null;

    @property(cc.AudioClip)
    scoreAudio: cc.AudioClip = null;

    private groundY: number = 0;
    private timer: number = 0;
    private starDuration: number = 0;
    private score: number = 0;

    spawnNewStar(): void {
        const newStar = cc.instantiate(this.starPrefab);
        this.node.addChild(newStar);
        newStar.getComponent('Star').game = this;
        newStar.setPosition(this.getNewStarPosition());
        this.starDuration = this.minStarDuration + Math.random() * (this.maxStarDuration - this.minStarDuration);
        this.timer = 0;
    }

    onLoad(): void {
        this.groundY = this.ground.y + this.ground.height / 2;
        this.timer = 0;
        this.starDuration = 0;  // Fix the typo here
        this.spawnNewStar();
        this.score = 0;
    }

    getNewStarPosition(): cc.Vec2 {
        const randX = 0;
        const randY = this.groundY + Math.random() * this.player.getComponent('Player').jumpHeight + 50;
        const maxX = this.node.width / 2;
        const newRandX = (Math.random() - 0.5) * 2 * maxX;
        return cc.v2(newRandX, randY);
    }

    update(dt: number): void {
        if (this.timer > this.starDuration) {
            this.gameOver();
            return;
        }
        this.timer += dt;
    }

    gainScore(): void {
        this.score += 1;
        this.scoreDisplay.string = 'Score: ' + this.score;
        cc.audioEngine.playEffect(this.scoreAudio, false);
    }

    gameOver(): void {
        if (this.player) {
            this.player.stopAllActions();
        } else {
            console.error("Player is not defined in gameOver function.");
        }

        cc.director.loadScene('game');
    }
}
