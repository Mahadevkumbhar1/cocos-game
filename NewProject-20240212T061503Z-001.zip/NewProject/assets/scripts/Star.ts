// cc.Class({
//     extends: cc.Component,

//     properties: {
//         pickRadius: 0,
//     },

//     getPlayerDistance: function() {
//         if (!this.game || !this.game.player) {
//             // Handle the case where this.game or this.game.player is not defined
//             return Number.MAX_VALUE; // or any other appropriate value
//         }

//         var playerPos = this.game.player.getPosition();
//         var dist = this.node.position.sub(playerPos).mag();
//         return dist;
//     },

//     onPicked: function() {
//         if (this.game) {
//             this.game.spawnNewStar();
//         }
    
//         if (this.game && this.game.gainScore) {
//             this.game.gainScore();
//         }
    
//         this.node.destroy();
//     },
    
//     // LIFE-CYCLE CALLBACKS:

//     // onLoad () {},

//     start () {

//     },

//     update: function(dt) {
//         if (this.getPlayerDistance() < this.pickRadius){
//             this.onPicked();
//             return;
//         }

//         var opacityRadio = 1 - this.game.timer/this.game.starDuration;
//         var minOpacity = 50;
//         this.node.opacity = minOpacity + Math.floor(opacityRadio * (255 - minOpacity));
//     },
// });
const { ccclass, property } = cc._decorator;

@ccclass
export default class YourComponentName extends cc.Component {

    @property
    pickRadius: number = 0;

    private getPlayerDistance(): number {
        if (!this.game || !this.game.player) {
            // Handle the case where this.game or this.game.player is not defined
            return Number.MAX_VALUE; // or any other appropriate value
        }

        const playerPos = this.game.player.getPosition();
        const dist = this.node.position.sub(playerPos).mag();
        return dist;
    }

    private onPicked() {
        if (this.game) {
            this.game.spawnNewStar();
        }

        if (this.game && this.game.gainScore) {
            this.game.gainScore();
        }

        this.node.destroy();
    }

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start() {}

    update(dt: number) {
        if (this.getPlayerDistance() < this.pickRadius) {
            this.onPicked();
            return;
        }

        const opacityRadio = 1 - this.game.timer / this.game.starDuration;
        const minOpacity = 50;
        this.node.opacity = minOpacity + Math.floor(opacityRadio * (255 - minOpacity));
    }
}
